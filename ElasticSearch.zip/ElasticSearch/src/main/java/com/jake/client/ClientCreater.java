package com.jake.client;

import org.elasticsearch.client.Client;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.ImmutableSettings;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;

public enum ClientCreater {

	_instance;
	private Client client = null;
	
	public Client getClient() {
		return client;
	}
	public void CreateClient() {
		if(client == null){
			Settings settings = ImmutableSettings.settingsBuilder().put("cluster.name", "elasticsearch").build();
			 client = new TransportClient(settings).addTransportAddress(new InetSocketTransportAddress("192.168.0.9", 9300));
			
		}
	}
	
	public void closeClient(Client client){
		 client.close();
	}
	public void closeClient(){
		 client.close();
	}
}
