package com;

import static org.elasticsearch.common.xcontent.XContentFactory.jsonBuilder;

import java.util.Date;

import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.client.Client;
import org.elasticsearch.search.SearchHit;

import com.jake.client.ClientCreater;
import com.jake.service.APIServices;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class AppTest extends TestCase
{
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public AppTest( String testName )
    {
        super( testName );
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( AppTest.class );
    }

    /**
     * Rigourous Test :-)
     * @throws Exception 
     */
    
    public void testBeforeStart() throws Exception{
    	
    	ClientCreater._instance.CreateClient();
    	Client client = ClientCreater._instance.getClient();
    	
    	String json = "{" + "\"user\":\"Jake Munta\","
				+ "\"postDate\":\"2013-01-30\","
				+ "\"message\":\"workinging Demo Elasticsearch jake\"" + "}";
		client.prepareIndex("jakemunta", "jake", "1").setSource(json).execute().actionGet();
		
		assertTrue(true);
    }
    
    
    
    public void testApp()
    {
    	
    	ClientCreater._instance.CreateClient();
    	Client client = ClientCreater._instance.getClient();
        assertNotNull(client);
    }
    
    public void testApp1()
    {
    	
    	ClientCreater._instance.CreateClient();
    	Client client = ClientCreater._instance.getClient();
    	 SearchHit[] hits = APIServices.searchDocument(client, "twitter", "tweet");
 		assertTrue(hits.length>0);
    	 SearchHit[] field = APIServices.searchDocumentByFields(client, "twitter", "tweet", "postDate", "2013-01-30");
    	 assertTrue(field.length>0);
    }
    
    public void testApp2()
    {
    	
    	ClientCreater._instance.CreateClient();
    	Client client = ClientCreater._instance.getClient();
    	 SearchHit[] hits = APIServices.searchDocument(client, "twitter", "tweet");
 		assertTrue(hits.length>0);
 		GetResponse response = APIServices.getDocument(client, "twitter", "tweet", "2");
    	 assertNotNull(response);
    	 assertEquals("twitter", response.getIndex());
    }
    
    public void testApp3()
    {
    	
    	ClientCreater._instance.CreateClient();
    	Client client = ClientCreater._instance.getClient();
    	 SearchHit[] hits = APIServices.searchDocument(client, "jakemunta", "jake");
 		assertTrue(hits.length>0);
 		GetResponse response = APIServices.getDocument(client, "jakemunta", "jake", "1");
 		assertNotNull(response);
 		assertEquals("jakemunta", response.getIndex());
    	 SearchHit[] field = APIServices.searchDocumentByFields(client, "jakemunta", "jake", "postDate", "2013-01-30");
    	 assertTrue(field.length>0);
    }
    
   
}
