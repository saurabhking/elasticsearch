$(".search-query" ).autocomplete({
    source: "/autocomplete",
    minLength: 2
});